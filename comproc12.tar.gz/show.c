#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
	char buffer[80];
	int aux[80];
	 if (argc != 2)
    {
      sprintf (buffer, "Error\n");
      write(2,buffer,strlen(buffer));
      exit (1);
	}
	sprintf(buffer,"%s",argv[1]);
	int fd = open(buffer,O_RDONLY);
	int n;
	while((n = read(fd,buffer,2)) != 0) {
		write(1,buffer,1);
		n = read(fd,buffer,sizeof(int)); //ENTER
		sprintf(buffer,"%d",buffer[0]);
		write(1,buffer,n);
		sprintf(buffer,"\n");
		write(1,buffer,strlen(buffer));
	} 	
}	
